using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;

namespace NovaChord.Common.Core
{
    /// <summary>
    ///     Per-NPC resonance state. Stacks and timers are maintained on the server
    ///     (see <see cref="ResonanceSystem" />) and mirrored to clients for the pip display.
    ///     Glacial marks passively chill; a glacial overflow briefly dampens bosses.
    /// </summary>
    public sealed class ResonanceGlobalNPC : GlobalNPC
    {
        public override bool InstancePerEntity => true;

        public int[] MarkStacks = new int[AttunementData.Count];
        public int[] MarkTimers = new int[AttunementData.Count];
        public int BossDampTimer;

        public override void PostAI(NPC npc)
        {
            if (!npc.active || npc.life <= 0)
            {
                for (int i = 0; i < AttunementData.Count; i++)
                {
                    MarkStacks[i] = 0;
                    MarkTimers[i] = 0;
                }
                BossDampTimer = 0;
                return;
            }

            for (int i = 0; i < AttunementData.Count; i++)
            {
                if (MarkTimers[i] > 0)
                {
                    MarkTimers[i]--;
                    if (MarkTimers[i] == 0)
                        MarkStacks[i] = 0;
                }
            }

            // Passive chill while glacial marks are present.
            if (MarkStacks[(int)Attunement.Glacial] > 0)
                npc.velocity *= npc.boss ? 0.985f : 0.96f;

            if (BossDampTimer > 0)
            {
                BossDampTimer--;
                npc.velocity *= 0.8f;
            }
        }

        public override void PostDraw(NPC npc, SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
        {
            if (Main.dedServ || npc.life <= 0)
                return;

            // Colored pips above the victim, one per mark stack, grouped by attunement.
            Texture2D pixel = TextureAssets.MagicPixel.Value;
            int total = 0;
            for (int i = 0; i < AttunementData.Count; i++)
                total += MarkStacks[i];
            if (total == 0)
                return;

            const int size = 5;
            const int gap = 7;
            float startX = screenPos.X - (total - 1) * gap * 0.5f;
            float y = screenPos.Y - npc.height * 0.5f - 16f;

            int drawn = 0;
            for (int i = 0; i < AttunementData.Count; i++)
            {
                Color color = ((Attunement)i).Primary();
                for (int s = 0; s < MarkStacks[i]; s++)
                {
                    Vector2 pos = new(startX + drawn * gap, y);
                    spriteBatch.Draw(pixel, pos, null, color * 0.9f, 0f, new Vector2(0.5f), size, SpriteEffects.None, 0f);
                    drawn++;
                }
            }
        }
    }
}
