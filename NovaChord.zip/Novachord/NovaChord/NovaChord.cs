using Terraria.ModLoader;

namespace NovaChord
{
    /// <summary>
    ///     Nova Chord: a single, deeply mechanical bow built around elemental resonance,
    ///     rhythm-based perfect draws and a gacha style "Finale" ultimate.
    ///     <para />
    ///     Rendering, particles, trails, UI and asset plumbing are delegated to
    ///     InnoVault, Luminance and Particle Library instead of being re-implemented here.
    /// </summary>
    public sealed class NovaChord : Mod
    {
        /// <summary>Internal mod name, used for shader ids and localization keys.</summary>
        public const string ModName = "NovaChord";

        /// <summary>Packet opcodes used by the mod's tiny net protocol.</summary>
        public enum Packet : byte
        {
            PlayerState = 0,
            ResonanceVisual = 1,
            FinaleStart = 2,
            PerfectRelease = 3
        }

        public override void HandlePacket(System.IO.BinaryReader reader, int whoAmI)
        {
            Packet packet = (Packet)reader.ReadByte();
            switch (packet)
            {
                case Packet.PlayerState:
                    Common.Core.CadencePlayer.ReceiveState(reader, whoAmI);
                    break;
                case Packet.ResonanceVisual:
                    Common.Core.ResonanceSystem.ReceiveVisual(reader);
                    break;
                case Packet.FinaleStart:
                    Common.Core.CadencePlayer.ReceiveFinale(reader, whoAmI);
                    break;
                case Packet.PerfectRelease:
                    Common.Core.CadencePlayer.ReceivePerfect(reader, whoAmI);
                    break;
            }
        }
    }
}
