using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Content.Buffs
{
    /// <summary>
    ///     Base class for the three elemental marks applied to enemies by Resonance Arrows.
    ///     Marks are debuffs; their stack counts live in <see cref="Common.Core.ResonanceGlobalNPC" />
    ///     and are rendered as pips above the victim. Reaching the cap triggers a Resonance Overflow.
    /// </summary>
    public abstract class MarkBuff : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.debuff[Type] = true;
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
            BuffID.Sets.NurseCannotRemoveDebuff[Type] = true;
        }

        public override void Update(NPC npc, ref int buffIndex)
        {
            // Stack bookkeeping is handled by ResonanceGlobalNPC; the buff only marks presence.
        }
    }
}
