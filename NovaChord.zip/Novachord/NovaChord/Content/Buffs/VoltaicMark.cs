namespace NovaChord.Content.Buffs
{
    /// <summary>Voltaic attunement mark. Overflow: chain lightning to nearby enemies.</summary>
    public sealed class VoltaicMark : MarkBuff { }
}
