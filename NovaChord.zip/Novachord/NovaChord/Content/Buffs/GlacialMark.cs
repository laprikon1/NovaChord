namespace NovaChord.Content.Buffs
{
    /// <summary>Glacial attunement mark. Overflow: frost nova that freezes non-boss enemies.</summary>
    public sealed class GlacialMark : MarkBuff { }
}
