using Microsoft.Xna.Framework;
using NovaChord.Common.Core;
using NovaChord.Content.Projectiles;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Content.Items
{
    /// <summary>
    ///     Starfall Cadence — a rhythm bow. Hold left click to draw; release inside the
    ///     highlighted cadence window for a Perfect Draw (bonus damage, Tempo stacks and
    ///     Finale gauge). Cycle attunements with V and unleash the Starfall Finale with B
    ///     once the gauge is full. Arrows are consumed on release, not on draw.
    /// </summary>
    public sealed class StarfallCadence : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 52;
            Item.damage = 68;
            Item.DamageType = DamageClass.Ranged;
            Item.knockBack = 4.5f;
            Item.crit = 8;
            Item.useTime = 20;
            Item.useAnimation = 20;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.useAmmo = AmmoID.Arrow;
            Item.shoot = ModContent.ProjectileType<CadenceHoldout>();
            Item.shootSpeed = 14f;
            Item.channel = true;
            Item.autoReuse = true;
            Item.noMelee = true;
            Item.noUseGraphic = true;
            Item.value = Item.sellPrice(gold: 6);
            Item.rare = ItemRarityID.Pink;
        }

        public override bool CanUseItem(Player player)
        {
            return !player.CCed && !player.dead && player.HasAmmo(Item);
        }

        // Ammo is consumed manually by the holdout on release, never by the vanilla draw.
        public override bool ConsumeAmmo(Player player, Item ammo) => false;

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.whoAmI != Main.myPlayer)
                return false;

            // A single holdout per player; re-use ticks while channeling must not duplicate it.
            int holdoutType = ModContent.ProjectileType<CadenceHoldout>();
            foreach (Projectile proj in Main.projectile)
            {
                if (proj.active && proj.owner == player.whoAmI && proj.type == holdoutType)
                    return false;
            }

            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            Projectile.NewProjectile(source, player.MountedCenter, Vector2.Zero, holdoutType, 0, 0f,
                player.whoAmI, (float)cadence.Attunement);
            return false;
        }

        public override void AddRecipes()
        {
            Recipe.Create(Type)
                .AddIngredient(ItemID.HallowedBar, 10)
                .AddIngredient(ItemID.SoulofLight, 12)
                .AddIngredient(ItemID.FallenStar, 25)
                .AddTile(TileID.MythrilAnvil)
                .Register();
        }
    }
}
