using System;
using Microsoft.Xna.Framework;
using ParticleLibrary.Core.V3.Particles;
using Terraria;

namespace NovaChord.Content.Particles
{
    /// <summary>
    ///     Slow, softly pulsing mote used for charged-draw and Finale ambience.
    ///     Drifts upward and sways gently; additive (alpha 0).
    /// </summary>
    public sealed class CadenceMoteBehavior : Behavior<ParticleInfo>
    {
        public override string Texture => "NovaChord/Assets/Textures/Particles/Mote";

        public override void Initialize(ref ParticleInfo info)
        {
            info.Velocity += new System.Numerics.Vector2(0f, -0.35f);
        }

        public override void Update(ref ParticleInfo info)
        {
            float life = info.Time / (float)info.Duration;
            float sway = MathF.Sin(info.Time * 0.12f + info.Position.X * 0.02f) * 0.04f;

            info.Velocity *= 0.985f;
            info.Position += info.Velocity + new System.Numerics.Vector2(sway, 0f);
            info.Rotation += 0.01f;

            float pulse = 0.75f + 0.25f * MathF.Sin(info.Time * 0.2f);
            float intensity = (life > 0.8f ? (1f - life) / 0.2f : life / 0.8f) * pulse;
            Color c = info.InitialColor;
            info.Color = new Color(c.R, c.G, c.B, 0) * intensity;
            info.Scale = info.InitialScale * (0.7f + 0.3f * pulse);

            info.Time--;
        }
    }
}
