using Microsoft.Xna.Framework;
using ParticleLibrary.Core.V3.Particles;

namespace NovaChord.Content.Particles
{
    /// <summary>
    ///     Additive spark used for impacts, perfect releases and resonance bursts.
    ///     Data[0] (optional) is the per-tick spin. Colors arrive with alpha 0, which
    ///     Particle Library treats as additive blending.
    /// </summary>
    public sealed class CadenceSparkBehavior : Behavior<ParticleInfo>
    {
        public override string Texture => "NovaChord/Assets/Textures/Particles/StarSpark";

        public override void Update(ref ParticleInfo info)
        {
            float spin = info.Data is { Length: > 0 } ? info.Data[0] : 0f;
            info.Rotation += spin;

            info.Velocity *= 0.94f;
            info.Position += info.Velocity;

            float life = info.Time / (float)info.Duration;
            // Quick fade-in, long fade-out; keep alpha at zero for additive blending.
            float intensity = life > 0.85f ? (1f - life) / 0.15f : life / 0.85f;
            Color c = info.InitialColor;
            info.Color = new Color(c.R, c.G, c.B, 0) * intensity;
            info.Scale = info.InitialScale * (0.55f + 0.45f * life);

            info.Time--;
        }
    }
}
